#include <iostream>
#include <cstring>
#include <vector>

using namespace std;

struct Pokemon
{
	char name[50]; // nome do Pokémon
	int id;		   // número de identificação do Pokémon
	int status;	   // 0: vazio, 1: ocupado, 2: removido
};

class Pokedex
{
private:
	int size;					// tamanho da tabela
	Pokemon *table;				// tabela hash
	vector<int> insertionOrder; // vetor para manter a ordem de inserção

	int hashFunction(int id, int i)
	{
		int hash1 = id % size;
		int hash2 = 1 + (id % (size - 1));
		return (hash1 + i * hash2) % size;
	}

public:
	Pokedex(int m)
	{
		size = m;
		table = new Pokemon[size];
		for (int i = 0; i < size; i++)
		{
			table[i].status = 0; // marca todas as posições como vazias
		}
	}

	~Pokedex()
	{
		delete[] table;
	}

	void insert(const char *name, int id)
	{
		int i = 0;
		int hash = hashFunction(id, i);

		while (table[hash].status == 1 || table[hash].status == 2)
		{
			i++;
			hash = hashFunction(id, i);
		}

		strncpy(table[hash].name, name, sizeof(table[hash].name));
		table[hash].id = id;
		table[hash].status = 1; // marca a posição como ocupada

		insertionOrder.push_back(hash); // armazena o índice na ordem de inserção
	}

	Pokemon *search(int id)
	{
		int i = 0;
		int hash = hashFunction(id, i);

		while (table[hash].status != 0 && table[hash].status != 2)
		{
			if (table[hash].status == 1 && table[hash].id == id)
			{
				return &table[hash]; // retorna o ponteiro para o Pokémon encontrado
			}

			i++;
			hash = hashFunction(id, i);
		}

		return NULL; // Pokémon não encontrado
	}

	void remove(int id)
	{
		Pokemon *pokemon = search(id);
		if (pokemon != NULL)
		{
			pokemon->status = 2; // marca a posição como removida
		}
	}

	void printPokedex()
	{
		for (int i = 0; i < insertionOrder.size(); i++)
		{
			int index = insertionOrder[i];
			if (table[index].status == 1)
			{
				cout << "ID: " << table[index].id << " | Name: " << table[index].name << endl;
			}
		}
	}
};

int main()
{
	int id;
	int m;
	cout << "Digite o tamanho da Pokedex: ";
	cin >> m;

	Pokemon *pokemon;
	Pokedex pokedex(m);

	int option = 0;
	while (option != 5)
	{
		cout << "\nMenu:\n";
		cout << "1 - Inserir Pokemon\n";
		cout << "2 - Pesquisar Pokemon\n";
		cout << "3 - Remover Pokemon\n";
		cout << "4 - Listar Pokedex\n";
		cout << "5 - Sair\n";
		cout << "Escolha uma opcao: ";
		cin >> option;

		switch (option)
		{
		case 1:
			char name[50];
			cout << "Digite o nome do Pokemon: ";
			cin.ignore(); // Ignora a quebra de linha pendente no buffer
			cin.getline(name, sizeof(name));
			cout << "Digite o ID do Pokemon: ";
			cin >> id;
			pokedex.insert(name, id);
			cout << "Pokemon inserido na Pokedex!\n";
			break;
		case 2:
			cout << "Digite o ID do Pokemon a ser pesquisado: ";
			cin >> id;
			pokemon = pokedex.search(id);
			if (pokemon != NULL)
			{
				cout << "Pokemon encontrado na Pokedex" << endl;
				cout << "Nome do Pokemon: " << pokemon->name << endl;
			}
			else
				cout << "Pokemon nao encontrado" << endl;
			break;
		case 3:
			cout << "Digite o ID do Pokemon a ser removido: ";
			cin >> id;

			pokemon = pokedex.search(id);
			if (pokemon != NULL)
			{
				pokedex.remove(id);
				cout << "Pokemon " << pokemon->name << " removido da Pokedex!\n";
			}
			else
			{
				cout << "Pokemon com ID " << id << " nao encontrado na Pokedex!\n";
			}
			break;

			break;
		case 4:
			cout << "\nPokedex:\n";
			pokedex.printPokedex();
			break;
		default:
			cout << "Opcao invalida! Tente novamente.\n";
		}
	}
	return 0;
}
